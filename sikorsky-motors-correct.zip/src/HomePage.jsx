import React from 'react';

export default function HomePage() {
  return (
    <div style={{
      padding: '2rem',
      fontFamily: 'Arial, sans-serif',
      textAlign: 'center'
    }}>
      <h1 style={{ fontSize: '2.5rem', marginBottom: '1rem' }}>Sikorsky Motors</h1>
      <p style={{ fontSize: '1.2rem' }}>Движение в будущее с отечественными бесколлекторными моторами.</p>
    </div>
  );
}